﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Synthesis;
using System.Speech.Recognition;
using System.Xml;

namespace Jarvis
{
    public partial class Form1 : Form
    {


        #region Dictionnaire...
        public static Dictionary<string, Param> DICO = new Dictionary<string, Param>();
        #endregion
        #region Structure...
        public struct Param // Ordre | Reponses{,,,,,} | FlagAction(true;false) | Action("")
        {
            //public static string Reponse;
            public List<string> Rep;
            public string Flag;
            public string Action;
        }
        #endregion

        string temp;
        string condition;

        SpeechSynthesizer s = new SpeechSynthesizer();
        Choices list = new Choices();
        SpeechRecognitionEngine rec = new SpeechRecognitionEngine();
        Boolean wake = true;
        String bufferEared = "";
        Param i;
        public static Random rdm = new Random();

        public Form1()
        {
            var streamReader = new StreamReader(new FileStream("C:\\Users\\David\\Desktop\\JarvisConfig.txt", FileMode.Open));
            
            #region LoadListConfig...
            while(!streamReader.EndOfStream)
            {
                var line = streamReader.ReadLine();
                var values = line.Split(';');                
                if (values[0] == "system")
                {
                    list.Add(values[1]);
                }
                else
                {
                    var reponses = values[1].Split(',');
                    List<string> answers = new List<string>();
                    foreach (string ans in reponses) { answers.Add(ans); }
                    i.Rep = answers;
                    i.Flag = values[2];
                    i.Action = values[3];
                    DICO.Add(values[0], i);
                    list.Add(values[0]);
                }
            }
            #endregion
            streamReader.Dispose();


            //list.Add(new String[] {""});


            Grammar gr = new Grammar(new GrammarBuilder(list));

            try
            {
                rec.RequestRecognizerUpdate();
                rec.LoadGrammar(gr);
                rec.SpeechRecognized += rec_SpeachRecognized;
                rec.SetInputToDefaultAudioDevice();
                rec.RecognizeAsync(RecognizeMode.Multiple);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            //s.Speak("test");
            s.SelectVoiceByHints(VoiceGender.Female);
            s.Speak("Hello !");
            InitializeComponent();
        }

        public void Say(String h)
        {
            rec.RecognizeAsyncStop();
            s.Speak(h);
            Console.WriteLine("j'ai répondu: " + h);
            Console.WriteLine("");
            Wait(1000);
            rec.RecognizeAsync(RecognizeMode.Multiple);
            
        }

        private void rec_SpeachRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            String r = e.Result.Text;
            Console.WriteLine("j'ai entendu: " + r);
            if (r == "wake") wake = true;
            if (r == "sleep")
            {
                wake = false;
                foreach (string ans in DICO.Keys)
                {
                    if (r == ans)
                    {
                        var u = rdm.Next(DICO[ans].Rep.Count);
                        var reponse = DICO[ans].Rep[u];
                        Say(reponse);
                    }
                }
            }

            if (bufferEared != r && wake == true)
            {
                foreach(string ans in DICO.Keys)
                {
                    if (r == ans)
                    {
                        var u = rdm.Next(DICO[ans].Rep.Count);
                        var reponse = DICO[ans].Rep[u];
                        Say(reponse);
                    }
                }
                if (r == "quelle heure est-il")
                {
                    Say("il est " + DateTime.Now.ToString("hh:mm"));
                }
                else if (r == "quel jour sommes nous")
                {
                    Say("nous sommes le " + DateTime.Now.ToString("d/M/yyyy"));
                }
                else if (r == "quel temps fait til")
                {                    
                    Say("Le ciel est, " + GetWeather("cond") + ".");
                    Say("Il fait, " + (Convert.ToInt32(GetWeather("temp")) - 32 ) * 5/9 + " degrer");
                }
                else
                {
                    //Say("Désolé je ne sais pas répondre à " + r);
                }
                bufferEared = r;
            }
        }

        public String GetWeather(String input)
        {
            String query = String.Format("https://query.yahooapis.com/v1/public/yql?q=select * from weather.forecast where woeid in (select woeid from geo.places(1) where text='Cergy, France')&format=xml&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys");
            XmlDocument wData = new XmlDocument();
            wData.Load(query);

            XmlNamespaceManager manager = new XmlNamespaceManager(wData.NameTable);
            manager.AddNamespace("yweather", "http://xml.weather.yahoo.com/ns/rss/1.0");

            XmlNode channel = wData.SelectSingleNode("query").SelectSingleNode("results").SelectSingleNode("channel");
            XmlNodeList nodes = wData.SelectNodes("query/results/channel");
            try
            {
                temp = channel.SelectSingleNode("item").SelectSingleNode("yweather:condition", manager).Attributes["temp"].Value;
                condition = channel.SelectSingleNode("item").SelectSingleNode("yweather:condition", manager).Attributes["text"].Value;
                //high = channel.SelectSingleNode("item").SelectSingleNode("yweather:forecast", manager).Attributes["high"].Value;
                //low = channel.SelectSingleNode("item").SelectSingleNode("yweather:forecast", manager).Attributes["low"].Value;
                if (input == "temp")
                {
                    return temp;
                }
                //if (input == "high")
                //{
                //    return high;
                //}
                //if (input == "low")
                //{
                //    return low;
                //}
                if (input == "cond")
                {
                    return condition;
                }
            }
            catch
            {
                return "Error Reciving data";
            }
            return "error";
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void Wait(int milliseconds)
        {
            Timer t1 = new Timer();
            if (milliseconds == 0 || milliseconds < 0) return;
            t1.Interval = milliseconds;
            t1.Enabled = true;
            t1.Start();
            t1.Tick += (s, e) =>
            {
                t1.Enabled = false;
                t1.Stop();
            };
            while (t1.Enabled)
            {
                Application.DoEvents();
            }

        }
    }
}
